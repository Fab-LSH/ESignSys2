# FASC OpenApi Python SDK v5.1 说明

# 简介

欢迎使用法大大开发者工具套件（SDK），Python SDK 是法大大电子合同和电子签云服务开放平台（FASC OPEN API）的配套工具。

# 版本说明

FASC.openAPI 产品目前存在两个子版本号：v5.0、v5.1， 均在持续迭代维护。 

当前页面SDK基于FASC.openAPI v5.1子版本开发，如需使用FASC.openAPI v5.0版本SDK，请访问： 

https://gitee.com/fadada-cloud/fasc-openapi-python-sdk/tree/v5.0

# 目录结构
- SDK项目层级     
```python
fasc_api
	- client  # 为客户端 。
	- exception # 主要包含客户端初始异常，以及服务端业务异常 。
	- utils # 包含了http,hash工具类方法 和全局常量等。
test # 里面是接口的调用示例，接入方开发人员可以参考    
```

- SDK 目前支持以下模块，对应 client 可支持具体的业务方法：

| 模块           | 模块中文名       | 模块说明                                                |
| -------------- | ---------------- |-----------------------------------------------------|
| ServiceClient  | 服务访问凭证     | 获取服务访问凭证                                            |
| UserClient     | 个人用户管理     | 包含应用的个人用户信息查询、禁用、恢复、解绑等                             |
| CorpClient     | 企业用户账号管理 | 包含应用的企业用户信息查询、禁用、恢复、解绑等                              |
| OrgClient      | 组织管理         | 包含企业成员查询                                            |
| SealClient     | 印章管理         | 包含印章查询、用印员查询                                        |
| DocClient      | 文件管理         | 包含网络文件上传、获取文件上传地址、文件处理                              |
| TemplateClient | 文档模板管理     | 包含文档模板查询、签署模板查询                                     |
| SignTaskClient | 签署任务管理     | 包含签署任务的创建、维护、各个流程节点的流转操作，以及签署任务查询、文件下载链接等            |
| EUIClient      | EUI页面链接管理  | 对EUI页面链接进行管理操作，如：获取个人授权链接、获取企业授权链接、获取计费链接、获取签署编辑链接等 |



# 依赖环境

1. python3.8版本及以上
2. 在法大大平台开通相应应用
3. 获取 appId、appSecret 及服务请求地址（serverUrl）



# 安装说明

本SDK是在python3.8环境下开发的，如果其他版本使用遇到问题请联系相关人员。解压fasc_api.zip的压缩包 后使用命令安装：

```python
python setup.py install
```

安装完sdk以后需要安装sdk使用的依赖包,执行以下命令安装：

```python
pip install -r requirements.txt
```

下面是配置以及获取accessToken的demo： accessToken的有效期是2个小时，不一定每一次请求都要获取accessToken。 调用set_access_token方法设置accessToken


```python
from fasc_api.client.client import ApiClient
from fasc_api.client.service_client import ServiceClient
from fasc_api.exception.exceptions import ClientException
from fasc_api.exception.exceptions import ServerException

# 指定请求 log 日志默认关闭
api_client = ApiClient('appId', 'appSecret', request_url='请求url', log=True)

# 设置超时时间 默认不设置 单位秒
api_client = ApiClient('appId', 'appSecret', request_url='请求url', log=True, timeout=2)

# 获取token
try:
    result = ServiceClient.get_access_token(api_client)
    print('token = %s' % result['data']['accessToken'])
except ClientException as  e:
    # 客户端初始化异常
    print(e)
except ServerException as e:
    # 服务端业务异常
    print(e)


```



# 版本更新日志

5.1.0 - 2022-07-28   基于FASC OpenAPI 5.1.0版本开发，初始版本。



# 参考

FASC OpenAPI (服务端) 接口文档 v5.1

https://dev.fadada.com/api-doc/MTE9YIK1SP/QMMRYYN5RMPREAZH/5-1 

