class CommonClient(object):
    pass
